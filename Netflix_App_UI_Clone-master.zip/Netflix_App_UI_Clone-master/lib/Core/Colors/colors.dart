import 'package:flutter/material.dart';

const kBackgroundColor = Colors.black;
const kWhiteBackground = Colors.white;
const kWhiteFont = Colors.white;
const kGreyIcon = Colors.grey;
const kGreyFont = Colors.grey;
final kButtonBlue = Colors.blueAccent[400];
const kButtonWhite = Colors.white;
const kButtonBlack = Colors.black;
const kBlackFont = Colors.black;
const kGreyBackground = Colors.grey;
const kRed = Colors.red;
