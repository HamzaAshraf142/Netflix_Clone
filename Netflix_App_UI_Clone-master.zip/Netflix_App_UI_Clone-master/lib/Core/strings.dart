const baseUrl = 'https://api.themoviedb.org/3';
const imageAppendUrl = 'https://image.tmdb.org/t/p/w500';
const logoAppendUrl = 'https://www.themoviedb.org/t/p/original';
const hostServerBaseUrl = 'https://cybertron.pythonanywhere.com';
