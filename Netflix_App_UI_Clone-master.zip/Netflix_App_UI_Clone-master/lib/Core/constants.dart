import 'package:flutter/material.dart';

const kWidth = SizedBox(width: 10);
const kHeight = SizedBox(height: 10);
const kHeightMedium = SizedBox(height: 15);
const kHeightLarge = SizedBox(height: 20);
